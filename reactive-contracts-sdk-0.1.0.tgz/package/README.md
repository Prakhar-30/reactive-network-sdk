# Reactive Contracts SDK

A JavaScript SDK for creating, customizing and deploying Reactive Smart Contracts for the Reactive Network.

## Overview

Reactive Network enables cross-chain communication through reactive smart contracts that listen for events on one chain and trigger callbacks on another chain. This SDK simplifies the process of creating reactive smart contracts by providing tools to generate contract code based on configuration parameters.

## Installation

```bash
npm install reactive-contracts-sdk
```

## Usage

### Basic Example

```javascript
const { ReactiveContractsSDK } = require('reactive-contracts-sdk');

// Create an instance of the SDK
const sdk = new ReactiveContractsSDK();

// Configure your reactive contract
const config = {
  contractName: 'MyReactiveContract',
  originChainId: 11155111, // Sepolia
  destinationChainId: 5318008, // Kopli
  originContract: '0x1234567890123456789012345678901234567890',
  destinationContract: '0x0987654321098765432109876543210987654321',
  eventSignature: 'TokensDeposited(address,bytes32,uint256)',
  callbackFunction: 'completeSwap(address,bytes32)',
  additionalConditions: [
    {
      expression: 'log.topic_3 > 0',
      errorMessage: 'Amount must be greater than 0'
    }
  ],
  callbackArgumentMapping: [
    { type: 'static', value: 'address(0)' },
    { type: 'topic', index: 1 }
  ]
};

// Generate the contract code
const contractCode = sdk.generateContract(config);
console.log(contractCode);

// Export the contract to a file
const filePath = sdk.exportContract(contractCode, config.contractName);
console.log(`Contract exported to: ${filePath}`);

// Or export as a full Forge project
const projectPath = sdk.exportForgeProject(contractCode, config.contractName);
console.log(`Forge project created at: ${projectPath}`);
```

### Getting Event Topic Hash

```javascript
const { ReactiveContractsSDK } = require('reactive-contracts-sdk');

const sdk = new ReactiveContractsSDK();
const eventSignature = 'Transfer(address,address,uint256)';
const topic0 = sdk.getEventTopic0(eventSignature);

console.log(`Event topic0 hash: ${topic0}`);
```

### Automatic Argument Mapping

```javascript
const { ReactiveContractsSDK } = require('reactive-contracts-sdk');

const sdk = new ReactiveContractsSDK();
const eventSignature = 'TokensDeposited(address indexed sender, bytes32 indexed id, uint256 amount)';
const callbackFunction = 'completeSwap(address sender, bytes32 id)';

const mapping = sdk.suggestArgumentMapping(eventSignature, callbackFunction);
console.log(mapping);
```

## Configuration Options

| Parameter | Type | Description |
|-----------|------|-------------|
| `contractName` | `string` | Name of the generated contract |
| `originChainId` | `number` | Chain ID where events are emitted |
| `destinationChainId` | `number` | Chain ID where callbacks are sent |
| `originContract` | `string` | Address of contract emitting events |
| `destinationContract` | `string` | Address of contract receiving callbacks |
| `eventSignature` | `string` | Event signature to listen for |
| `callbackFunction` | `string` | Function signature to call |
| `callbackGasLimit` | `number` | (Optional) Gas limit for callbacks (default: 3000000) |
| `additionalConditions` | `array` | (Optional) Additional requirements for handling events |
| `callbackArgumentMapping` | `array` | (Optional) Mapping of event data to callback args |

## Callback Argument Mapping

The `callbackArgumentMapping` array defines how to map event data to callback function arguments:

- `{ type: 'static', value: 'address(0)' }` - Static value
- `{ type: 'topic', index: 1, cast: 'address' }` - Map from event topic
- `{ type: 'data', dataFormat: 'decoded', dataType: 'uint256' }` - Map from event data

## Supported Chains

The SDK includes constants for commonly used chain IDs:

```javascript
const { CHAIN_IDS } = require('reactive-contracts-sdk');

console.log(CHAIN_IDS.SEPOLIA); // 11155111
console.log(CHAIN_IDS.KOPLI);   // 5318008
```

## License

MIT